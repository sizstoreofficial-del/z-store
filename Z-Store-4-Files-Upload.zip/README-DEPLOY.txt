Z STORE - FILE UPLOAD
=====================

Upload these files into the GitHub repository z-store:

1. package.json
2. render.yaml
3. zstore-payment-server.js
4. README-DEPLOY.txt

File index.html is already uploaded separately.

IMPORTANT:
- Do not rename the files.
- Do not edit their contents.
- The payment server needs the XENDIT_SECRET_KEY environment variable on Render later.
