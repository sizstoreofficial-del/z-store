// Z Store Payment Server - Xendit Payment API v3
// Jalankan dengan: node zstore-payment-server.js
// Sebelum menjalankan, set XENDIT_SECRET_KEY di environment.

const http = require('http');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const PORT = Number(process.env.PORT || 3000);
const SECRET = process.env.XENDIT_SECRET_KEY || '';
const WEBHOOK_TOKEN = process.env.XENDIT_WEBHOOK_TOKEN || '';

const headers = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, x-callback-token',
  'Content-Type': 'application/json; charset=utf-8',
};

function send(res, status, body) {
  res.writeHead(status, headers);
  res.end(JSON.stringify(body));
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let data = '';
    req.on('data', chunk => {
      data += chunk;
      if (data.length > 1_000_000) req.destroy();
    });
    req.on('end', () => {
      try { resolve(data ? JSON.parse(data) : {}); }
      catch { reject(new Error('JSON tidak valid')); }
    });
    req.on('error', reject);
  });
}

function paymentAction(actions = [], preferred) {
  const list = Array.isArray(actions) ? actions : [];
  const wanted = preferred === 'QRIS'
    ? list.find(a => a.descriptor === 'QR_STRING')
    : list.find(a => a.type === 'REDIRECT_CUSTOMER' && a.descriptor === 'DEEPLINK_URL');
  return wanted
    || list.find(a => a.type === 'REDIRECT_CUSTOMER' && a.descriptor === 'WEB_URL')
    || list.find(a => a.type === 'PRESENT_TO_CUSTOMER' && a.descriptor === 'QR_STRING')
    || null;
}

function safeOrder(body) {
  const payment = String(body.payment || '');
  const channel = payment === 'DANA' ? 'DANA' : payment === 'GoPay' ? 'GOPAY' : payment === 'QRIS' ? 'QRIS' : '';
  const amount = Number(body.amount);
  const reference_id = String(body.reference_id || '').trim();
  if (!channel) throw new Error('Metode pembayaran tidak didukung.');
  if (!Number.isInteger(amount) || amount < 100 || amount > 20000000) throw new Error('Nominal pembayaran tidak valid.');
  if (!reference_id || reference_id.length > 255) throw new Error('Order ID tidak valid.');
  return { ...body, payment, channel, amount, reference_id };
}

async function xenditRequest(path, options = {}) {
  if (!SECRET) throw new Error('XENDIT_SECRET_KEY belum dikonfigurasi di server.');
  const auth = Buffer.from(`${SECRET}:`).toString('base64');
  const response = await fetch(`https://api.xendit.co${path}`, {
    ...options,
    headers: {
      'Authorization': `Basic ${auth}`,
      'Content-Type': 'application/json',
      'api-version': '2024-11-11',
      ...(options.headers || {})
    }
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    const msg = data?.message || data?.error_code || `Xendit HTTP ${response.status}`;
    throw new Error(msg);
  }
  return data;
}

async function createPayment(body) {
  const order = safeOrder(body);
  const payload = {
    reference_id: order.reference_id,
    type: 'PAY',
    country: 'ID',
    currency: 'IDR',
    request_amount: order.amount,
    capture_method: 'AUTOMATIC',
    channel_code: order.channel,
    description: `Z Store - ${order.diamond || 'Top Up'}`,
    metadata: {
      game: String(order.game || 'Free Fire'),
      diamond: String(order.diamond || ''),
      player_id: String(order.playerId || ''),
      server: String(order.server || '')
    }
  };

  const publicBase = process.env.PUBLIC_BASE_URL;
  if (publicBase && /^https:\/\//i.test(publicBase)) {
    payload.channel_properties = {
      success_return_url: `${publicBase.replace(/\/$/, '')}/payment-success?order=${encodeURIComponent(order.reference_id)}`,
      failure_return_url: `${publicBase.replace(/\/$/, '')}/payment-failed?order=${encodeURIComponent(order.reference_id)}`
    };
  }

  const idempotencyKey = crypto.createHash('sha256')
    .update(`${order.reference_id}:${order.amount}:${order.channel}`)
    .digest('hex');

  const data = await xenditRequest('/v3/payment_requests', {
    method: 'POST',
    headers: { 'idempotency-key': idempotencyKey },
    body: JSON.stringify(payload)
  });

  const action = paymentAction(data.actions, order.payment);
  const result = {
    ok: true,
    payment_request_id: data.payment_request_id,
    reference_id: data.reference_id,
    status: data.status,
    amount: data.request_amount,
    channel: data.channel_code,
    deeplink: order.payment !== 'QRIS' ? (action?.value || null) : null,
    qr_string: order.payment === 'QRIS' && action?.descriptor === 'QR_STRING' ? action.value : null,
    descriptor: action?.descriptor || null,
    actions: data.actions || []
  };
  return result;
}

async function getPaymentStatus(paymentRequestId) {
  if (!/^pr-[a-z0-9-]{20,}$/i.test(String(paymentRequestId || ''))) throw new Error('Payment request ID tidak valid.');
  const data = await xenditRequest(`/v3/payment_requests/${encodeURIComponent(paymentRequestId)}`, { method: 'GET' });
  return {
    ok: true,
    payment_request_id: data.payment_request_id,
    reference_id: data.reference_id,
    status: data.status,
    amount: data.request_amount,
    channel: data.channel_code,
    failure_code: data.failure_code || null
  };
}

const INDEX_HTML = path.join(__dirname, 'index.html');

function serveIndex(res) {
  try {
    const html = fs.readFileSync(INDEX_HTML, 'utf8');
    res.writeHead(200, {
      'Content-Type': 'text/html; charset=utf-8',
      'Cache-Control': 'no-cache'
    });
    res.end(html);
  } catch (err) {
    send(res, 500, { ok: false, error: 'index.html tidak ditemukan.' });
  }
}

const server = http.createServer(async (req, res) => {
  if (req.method === 'OPTIONS') {
    res.writeHead(204, headers); return res.end();
  }

  if (req.method === 'GET' && (req.url === '/' || req.url === '/index.html')) {
    return serveIndex(res);
  }

  if (req.method === 'GET' && req.url.startsWith('/payment-success')) {
    const url = new URL(req.url, 'http://localhost');
    const order = url.searchParams.get('order') || '';
    res.writeHead(200, {'Content-Type':'text/html; charset=utf-8'});
    return res.end(`<!doctype html><meta name=viewport content="width=device-width,initial-scale=1"><title>Z Store - Pembayaran</title><body style="font-family:Arial;text-align:center;padding:48px;background:#0b1020;color:white"><h1>✅ Pembayaran berhasil</h1><p>Order: <b>${order.replace(/[<>]/g,'')}</b></p><p>Silakan kembali ke Z Store.</p><a href="/" style="color:#8ab4ff">Kembali ke Z Store</a></body>`);
  }

  if (req.method === 'GET' && req.url.startsWith('/payment-failed')) {
    const url = new URL(req.url, 'http://localhost');
    const order = url.searchParams.get('order') || '';
    res.writeHead(200, {'Content-Type':'text/html; charset=utf-8'});
    return res.end(`<!doctype html><meta name=viewport content="width=device-width,initial-scale=1"><title>Z Store - Pembayaran</title><body style="font-family:Arial;text-align:center;padding:48px;background:#0b1020;color:white"><h1>❌ Pembayaran belum berhasil</h1><p>Order: <b>${order.replace(/[<>]/g,'')}</b></p><p>Kamu bisa kembali dan mencoba lagi.</p><a href="/" style="color:#8ab4ff">Kembali ke Z Store</a></body>`);
  }

  if (req.method === 'GET' && req.url === '/api/health') {
    return send(res, 200, { ok: true, configured: Boolean(SECRET), provider: 'Xendit' });
  }

  if (req.method === 'POST' && req.url === '/api/create-payment') {
    try {
      const body = await readBody(req);
      const result = await createPayment(body);
      return send(res, 200, result);
    } catch (err) {
      return send(res, 400, { ok: false, error: err.message });
    }
  }

  if (req.method === 'GET' && req.url.startsWith('/api/payment-status')) {
    try {
      const url = new URL(req.url, 'http://localhost');
      const result = await getPaymentStatus(url.searchParams.get('payment_request_id'));
      return send(res, 200, result);
    } catch (err) {
      return send(res, 400, { ok: false, error: err.message });
    }
  }

  if (req.method === 'POST' && req.url === '/api/webhooks/xendit') {
    try {
      if (WEBHOOK_TOKEN && req.headers['x-callback-token'] !== WEBHOOK_TOKEN) {
        return send(res, 401, { ok: false, error: 'Webhook token tidak cocok.' });
      }
      const event = await readBody(req);
      console.log('[XENDIT WEBHOOK]', JSON.stringify(event));
      // Jangan menganggap browser sebagai sumber kebenaran pembayaran.
      // Tahap fulfillment/admin dapat membaca event SUCCEEDED dari sini.
      return send(res, 200, { received: true, status: event?.data?.status || event?.status || null });
    } catch (err) {
      return send(res, 400, { ok: false, error: err.message });
    }
  }

  send(res, 404, { ok: false, error: 'Endpoint tidak ditemukan.' });
});

server.listen(PORT, () => {
  console.log(`Z Store Payment Server berjalan di http://localhost:${PORT}`);
  if (!SECRET) console.log('PERINGATAN: XENDIT_SECRET_KEY belum diisi.');
});
